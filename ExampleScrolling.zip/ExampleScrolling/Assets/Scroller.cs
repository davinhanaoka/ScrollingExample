﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scroller : MonoBehaviour {
    public float startX = 8f;
    public float endX = -8f;

    public float speed = 5f;

    public int direction = 1;

    void Update() {
        transform.Translate(speed * Time.deltaTime * direction, 0f, 0f);

        if (transform.position.x <= endX || transform.position.x >= startX) {
            direction *= -1;
        }
    }
}
